import {Given,When,Then } from "@badeball/cypress-cucumber-preprocessor"
import GetDate from "../../GetDate";
Given('User is on  Login page',()=>
{
    cy.visit("https://navistarfs.riversand.com/")
})
When('user Enter Username',function()
{
    cy.get("[type='email']").type(Cypress.env('username'))
});
When('user Enter Password',function()
{
    cy.get("[type='email']").type(Cypress.env('username'))
});
When('user click on Login button',function()
{
    cy.contains('Log In').click() 
     cy.wait(5000)
     cy.url().should('include',Cypress.env('assert_var'))
});
When('after succesfull login user click on Quick Actions button',function()
{
    cy.contains("Quick Actions").click()
});
When('user click on "Vendor Item" and User needs to fill mandatory attributes to create "Vendor Item"',function()
{
    cy.get("#actionItem").contains("Vendor Item").click()
     cy.wait(17000)
});
When('user  clicks on "Brand AAIAID" and selects value from the given dropdown "Brand AAIAID"',function()
{
    cy.get("[title='Brand AAIAID']").next().click({force:true})
    cy.get("[class='p-relative without-select-all-checkbox'] [id='input']").type("A004 ",{force:true})
    cy.get("[class='not-only-option']").click({force:true})
});
When('user  clicks on "Brand AAIAID" and selects value from the given dropdown "Brand AAIAID"',function()
{
    cy.get("[title='Brand AAIAID']").next().click({force:true})
});


